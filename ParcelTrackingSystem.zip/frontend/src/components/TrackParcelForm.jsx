
import React, { useState } from "react";
import axios from "axios";

export default function TrackParcelForm() {
  const [tracking, setTracking] = useState("");
  const [parcel, setParcel] = useState(null);

  const handleTrack = async (e) => {
    e.preventDefault();
    const res = await axios.get(`http://localhost:8080/api/v1/parcels/${tracking}`);
    setParcel(res.data);
  };

  return (
    <div>
      <form onSubmit={handleTrack}>
        <input placeholder="Enter tracking number" value={tracking} onChange={(e) => setTracking(e.target.value)} />
        <button type="submit">Track</button>
      </form>
      {parcel && (
        <div>
          <h3>Status: {parcel.status}</h3>
          <p>Receiver: {parcel.receiverName}</p>
        </div>
      )}
    </div>
  );
}
