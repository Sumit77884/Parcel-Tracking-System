
import React, { useState } from "react";
import axios from "axios";

export default function RegisterParcelForm() {
  const [form, setForm] = useState({ receiverName: "", receiverPhone: "", receiverAddress: "", weightKg: "" });
  const [trackingNumber, setTrackingNumber] = useState("");

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post("http://localhost:8080/api/v1/parcels", { ...form, senderId: 1 });
    setTrackingNumber(res.data.trackingNumber);
  };

  return (
    <div>
      <h2>Register New Parcel</h2>
      <form onSubmit={handleSubmit}>
        <input name="receiverName" placeholder="Receiver Name" onChange={handleChange} />
        <input name="receiverPhone" placeholder="Phone" onChange={handleChange} />
        <input name="receiverAddress" placeholder="Address" onChange={handleChange} />
        <input name="weightKg" placeholder="Weight (kg)" onChange={handleChange} />
        <button type="submit">Register</button>
      </form>
      {trackingNumber && <p>Tracking Number: <b>{trackingNumber}</b></p>}
    </div>
  );
}
