
import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import RegisterParcelForm from "./components/RegisterParcelForm";
import TrackParcelForm from "./components/TrackParcelForm";

export default function App() {
  return (
    <BrowserRouter>
      <nav>
        <Link to="/">Home</Link> | <Link to="/register">Register</Link> | <Link to="/track">Track</Link>
      </nav>
      <Routes>
        <Route path="/" element={<h2>Welcome to Parcel Tracking System</h2>} />
        <Route path="/register" element={<RegisterParcelForm />} />
        <Route path="/track" element={<TrackParcelForm />} />
      </Routes>
    </BrowserRouter>
  );
}
